from .wxhandler import wxHandler, wxHandler1

__all__ = ['wxHandler']
